

utils::globalVariables(c("subjectID","optionA","optionB","Iratio","item",
                         "item1", "item2","SD", "n.W", "meanItem", "SE","upr",
                         "lwr","label","estimate"))
